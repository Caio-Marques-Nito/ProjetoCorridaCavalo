﻿namespace CorridaDeCavalos
{
    partial class PistaCorrida
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.IniciarCorrida = new System.Windows.Forms.Button();
            this.CavalosCorrendo = new System.Windows.Forms.Timer(this.components);
            this.Cavalo2 = new System.Windows.Forms.PictureBox();
            this.Cavalo3 = new System.Windows.Forms.PictureBox();
            this.Cavalo4 = new System.Windows.Forms.PictureBox();
            this.Cavalo1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Velocimetro = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo1)).BeginInit();
            this.SuspendLayout();
            // 
            // IniciarCorrida
            // 
            this.IniciarCorrida.Location = new System.Drawing.Point(483, 364);
            this.IniciarCorrida.Name = "IniciarCorrida";
            this.IniciarCorrida.Size = new System.Drawing.Size(76, 40);
            this.IniciarCorrida.TabIndex = 4;
            this.IniciarCorrida.Text = "Iniciar";
            this.IniciarCorrida.UseVisualStyleBackColor = true;
            this.IniciarCorrida.Click += new System.EventHandler(this.IniciarCorrida_Click);
            // 
            // CavalosCorrendo
            // 
            this.CavalosCorrendo.Interval = 10;
            this.CavalosCorrendo.Tick += new System.EventHandler(this.CavalosCorrendo_Tick);
            // 
            // Cavalo2
            // 
            this.Cavalo2.Image = global::CorridaDeCavalos.Properties.Resources.JonnyCavalo__1_;
            this.Cavalo2.Location = new System.Drawing.Point(92, 152);
            this.Cavalo2.Name = "Cavalo2";
            this.Cavalo2.Size = new System.Drawing.Size(53, 49);
            this.Cavalo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cavalo2.TabIndex = 3;
            this.Cavalo2.TabStop = false;
            // 
            // Cavalo3
            // 
            this.Cavalo3.Image = global::CorridaDeCavalos.Properties.Resources.JonnyCavalo__1_;
            this.Cavalo3.Location = new System.Drawing.Point(92, 227);
            this.Cavalo3.Name = "Cavalo3";
            this.Cavalo3.Size = new System.Drawing.Size(53, 49);
            this.Cavalo3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cavalo3.TabIndex = 2;
            this.Cavalo3.TabStop = false;
            // 
            // Cavalo4
            // 
            this.Cavalo4.Image = global::CorridaDeCavalos.Properties.Resources.JonnyCavalo__1_;
            this.Cavalo4.Location = new System.Drawing.Point(92, 302);
            this.Cavalo4.Name = "Cavalo4";
            this.Cavalo4.Size = new System.Drawing.Size(53, 49);
            this.Cavalo4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cavalo4.TabIndex = 1;
            this.Cavalo4.TabStop = false;
            // 
            // Cavalo1
            // 
            this.Cavalo1.Image = global::CorridaDeCavalos.Properties.Resources.JonnyCavalo__1_;
            this.Cavalo1.Location = new System.Drawing.Point(92, 72);
            this.Cavalo1.Name = "Cavalo1";
            this.Cavalo1.Size = new System.Drawing.Size(53, 49);
            this.Cavalo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Cavalo1.TabIndex = 0;
            this.Cavalo1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(689, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Chegada";
            // 
            // Velocimetro
            // 
            this.Velocimetro.Interval = 1500;
            this.Velocimetro.Tick += new System.EventHandler(this.Velocimetro_Tick);
            // 
            // PistaCorrida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.IniciarCorrida);
            this.Controls.Add(this.Cavalo2);
            this.Controls.Add(this.Cavalo3);
            this.Controls.Add(this.Cavalo4);
            this.Controls.Add(this.Cavalo1);
            this.Name = "PistaCorrida";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cavalo1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Cavalo1;
        private System.Windows.Forms.PictureBox Cavalo4;
        private System.Windows.Forms.PictureBox Cavalo3;
        private System.Windows.Forms.PictureBox Cavalo2;
        private System.Windows.Forms.Button IniciarCorrida;
        private System.Windows.Forms.Timer CavalosCorrendo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer Velocimetro;
    }
}

