﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CorridaDeCavalos
{
    public partial class PistaCorrida : Form
    {
        public int CorridaCavalo1 = 0;
        public int CorridaCavalo2 = 0;
        public int CorridaCavalo3 = 0;
        public int CorridaCavalo4 = 0;

        Random Velocidade = new Random();

        public PistaCorrida()
        {
            InitializeComponent(); 
        }

        private void IniciarCorrida_Click(object sender, EventArgs e)
        {
            CavalosCorrendo.Enabled = true;
            Velocimetro.Enabled = true;
        }

        private void CavalosCorrendo_Tick(object sender, EventArgs e)
        {
            Cavalo1.Location = new Point(Cavalo1.Location.X + 1 + CorridaCavalo1, Cavalo1.Location.Y);
            Cavalo2.Location = new Point(Cavalo2.Location.X + 1 + CorridaCavalo2, Cavalo2.Location.Y);
            Cavalo3.Location = new Point(Cavalo3.Location.X + 1 + CorridaCavalo3, Cavalo3.Location.Y);
            Cavalo4.Location = new Point(Cavalo4.Location.X + 1 + CorridaCavalo4, Cavalo4.Location.Y);


            if (Cavalo1.Location.X == label1.Location.X || Cavalo2.Location.X == label1.Location.X || Cavalo3.Location.X == label1.Location.X || Cavalo4.Location.X == label1.Location.X)
            {
                CavalosCorrendo.Enabled = false;
                Velocimetro.Enabled = false;
            }
        }

        private void Velocimetro_Tick(object sender, EventArgs e)
        {
            CorridaCavalo1 = Velocidade.Next(0, 3);
            CorridaCavalo2 = Velocidade.Next(0, 3);
            CorridaCavalo3 = Velocidade.Next(0, 3);
            CorridaCavalo4 = Velocidade.Next(0, 3);
        }
    }
}
